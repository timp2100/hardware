#include "motor.h"

void MotorInit(MOTOR *Motor, PID *PosPID, int32_t PosAllowedError,
                void MotorGetPosFeedback(MOTOR *Motor),
                void MotorSetPosTarget(MOTOR *Motor, int32_t PosTarget),
                void MotorSetOutputMax(MOTOR *Motor, int32_t OutputMax),
                void MotorPidCalculate(MOTOR *Motor),
                void MotorOutput(MOTOR *Motor),
                bool MotorPosArrived(MOTOR *Motor))
{
  Motor->PidOutput = 0;
  Motor->SpeedFeedback = 0;
  Motor->PosFeedback = 0;
  Motor->PosTarget = 0;
  Motor->PosAllowedError = PosAllowedError;
  Motor->PosPID = PosPID;
  Motor->MotorGetPosFeedback = MotorGetPosFeedback;
  Motor->MotorSetPosTarget = MotorSetPosTarget;
  Motor->MotorSetOutputMax = MotorSetOutputMax;
  Motor->MotorPidCalculate = MotorPidCalculate;
  Motor->MotorOutput = MotorOutput;
  Motor->MotorPosArrived = MotorPosArrived;
}

void MotorSetPosTarget(MOTOR *Motor, int32_t PosTarget) {Motor->PosPID->Target = PosTarget;}
void MotorSetOutputMax(MOTOR *Motor, int32_t OutputMax) {Motor->PosPID->OutputMax = OutputMax;}
void MotorPidCalculate(MOTOR *Motor) {Motor->PidOutput = Position_PIDCalculate(Motor->PosPID);}
bool MotorPosArrived(MOTOR *Motor) {if (((Motor->PosFeedback - Motor->PosPID->Target) < Motor->PosAllowedError) && ((Motor->PosFeedback - Motor->PosPID->Target) > -Motor->PosAllowedError)) return true; return false;}

void Motor0GetPosFeedback(MOTOR *Motor)
{
  static int32_t PrePulse = 0;
  int32_t Pulse = 0;
  int32_t DeltaPulse = 0;
  
  Pulse = htim1.Instance -> CNT;
  DeltaPulse = Pulse - PrePulse;
  
  if(DeltaPulse > 32768)
  {
    DeltaPulse -= 65536;
  }
  else if(DeltaPulse < -32768)
  {
    DeltaPulse += 65536;
  }
  
  PrePulse = Pulse;
  
  Motor->SpeedFeedback = DeltaPulse;
  Motor->PosFeedback += Motor->SpeedFeedback;
  Motor->PosPID->Feedback = Motor->PosFeedback;
}

void Motor0Output(MOTOR *Motor)
{
  if (Motor->PidOutput >= 0) {htim16.Instance -> CCR1 = Motor->PidOutput; htim17.Instance -> CCR1 = 0;}
  else {htim16.Instance -> CCR1 = 0; htim17.Instance -> CCR1 = -Motor->PidOutput;}
}

void Motor1Output(int32_t Output)
{
	if (Output < -20000) Output = -20000;
	if (Output > 20000) Output = 20000;
  if (Output >= 0) {htim3.Instance -> CCR1 = Output; htim3.Instance -> CCR2 = 0;}
  else {htim3.Instance -> CCR1 = 0; htim3.Instance -> CCR2 = -Output;}
}
void Motor2Output(int32_t Output)
{
	if (Output < -20000) Output = -20000;
	if (Output > 20000) Output = 20000;
  if (Output >= 0) {htim3.Instance -> CCR3 = Output; htim3.Instance -> CCR4 = 0;}
  else {htim3.Instance -> CCR3 = 0; htim3.Instance -> CCR4 = -Output;}
}

void Motor1Disable() {htim3.Instance -> CCR1 = 0; htim3.Instance -> CCR2 = 0;}
void Motor2Disable() {htim3.Instance -> CCR3 = 0; htim3.Instance -> CCR4 = 0;}
void Motor1Break() {htim3.Instance -> CCR1 = 20000; htim3.Instance -> CCR2 = 20000;}
void Motor2Break() {htim3.Instance -> CCR3 = 20000; htim3.Instance -> CCR4 = 20000;}
