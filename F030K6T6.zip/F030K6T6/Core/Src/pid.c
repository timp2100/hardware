#include "pid.h"

void Position_PIDInit(PID *Position_PID, float Kp, float Ki, float Kd, int32_t IntegralMax, int32_t OutputMax)
{
  Position_PID->Target = 0;
  Position_PID->Feedback = 0;
  Position_PID->Error = 0;
  Position_PID->PreError = 0;
  Position_PID->DeltaError = 0;
  Position_PID->Integral = 0;

  Position_PID->Kp = Kp;
  Position_PID->Ki = Ki;
  Position_PID->Kd = Kd;

  Position_PID->Output = 0;
  Position_PID->IntegralMax = IntegralMax;
  Position_PID->OutputMax = OutputMax;
}

int32_t Position_PIDCalculate(PID *Position_PID)
{
  Position_PID->Error = Position_PID->Target - Position_PID->Feedback;
  Position_PID->Integral += Position_PID->Error;
  Position_PID->DeltaError = Position_PID->Error - Position_PID->PreError;
  
  if (Position_PID->Ki * Position_PID->Integral > Position_PID->IntegralMax)
  {
    Position_PID->Integral = Position_PID->IntegralMax / Position_PID->Ki;
  }
  else if (Position_PID->Ki * Position_PID->Integral < -Position_PID->IntegralMax)
  {
    Position_PID->Integral = -Position_PID->IntegralMax / Position_PID->Ki;
  }

  Position_PID->Output = (Position_PID->Kp * Position_PID->Error + Position_PID->Ki * Position_PID->Integral + Position_PID->Kd * Position_PID->DeltaError);

  if (Position_PID->Output >= Position_PID->OutputMax)
  {
    Position_PID->Output = Position_PID->OutputMax;
  }
  else if (Position_PID->Output <= -Position_PID->OutputMax)
  {
    Position_PID->Output = -Position_PID->OutputMax;
  }

  Position_PID->PreError = Position_PID->Error;
  return Position_PID->Output;
}
