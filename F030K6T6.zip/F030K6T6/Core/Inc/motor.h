#ifndef __MOTOR_H
#define __MOTOR_H

#include "tim.h"
#include "pid.h"

typedef struct _MOTOR
{
  int32_t PidOutput;
  int32_t SpeedFeedback;
  int32_t PosFeedback;
  int32_t PosTarget;
  int32_t PosAllowedError;
  PID *PosPID;
  
  void (*MotorGetPosFeedback)
  (
    struct _MOTOR *Motor
  );
  
  void (*MotorSetPosTarget)
  (
    struct _MOTOR *Motor,
    int32_t PosTarget
  );
    
  void (*MotorSetOutputMax)
  (
    struct _MOTOR *Motor,
    int32_t OutputMax
  );
  
  void (*MotorPidCalculate)
  (
    struct _MOTOR *Motor
  );
  
  void (*MotorOutput)
  (
    struct _MOTOR *Motor
  );
  
  bool (*MotorPosArrived)
  (
    struct _MOTOR *Motor
  );
}MOTOR;
void MotorInit(MOTOR *Motor, PID *PosPID, int32_t PosAllowedError,
                void MotorGetPosFeedback(MOTOR *Motor),
                void MotorSetPosTarget(MOTOR *Motor, int32_t PosTarget),
                void MotorSetOutputMax(MOTOR *Motor, int32_t OutputMax),
                void MotorPidCalculate(MOTOR *Motor),
                void MotorOutput(MOTOR *Motor),
                bool MotorPosArrived(MOTOR *Motor));

void MotorSetPosTarget(MOTOR *Motor, int32_t PosTarget);
void MotorSetOutputMax(MOTOR *Motor, int32_t OutputMax);
void MotorPidCalculate(MOTOR *Motor);
bool MotorPosArrived(MOTOR *Motor);

void Motor0GetPosFeedback(MOTOR *Motor);

void Motor0Output(MOTOR *Motor);
								
void Motor1Output(int32_t Output);
void Motor2Output(int32_t Output);

void Motor1Disable(void);
void Motor2Disable(void);
void Motor1Break(void);
void Motor2Break(void);

#endif /* __MOTOR_H */
