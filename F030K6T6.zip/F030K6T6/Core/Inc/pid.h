#ifndef __PID_H
#define __PID_H

#include "stdint.h"

typedef struct _PID
{
  int32_t Target;
  int32_t Feedback;

  int32_t Error;
  int32_t PreError;
  int32_t DeltaError;
  int32_t Integral;

  float Kp;
  float Ki;
  float Kd;

  int32_t Output;
  int32_t IntegralMax;
  int32_t OutputMax;
}PID;
void Position_PIDInit(PID *Position_PID, float Kp, float Ki, float Kd, int32_t IntegralMax, int32_t OutputMax);
int32_t Position_PIDCalculate(PID *Position_PID);

#endif /* __PID_H */
