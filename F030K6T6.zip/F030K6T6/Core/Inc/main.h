/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2022 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f0xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "stdbool.h"
#include "stdio.h"
#include "string.h"
#include "math.h"
#include "stdlib.h"
#include "motor.h"

#define BUFFER_SIZE             1024
#define ADD_SIZE                128

extern int8_t MOTOR1_SIGN;
extern uint8_t RxBuffer[];
extern uint32_t NowIndex;
extern uint32_t NextIndex;
/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define LED_Pin GPIO_PIN_0
#define LED_GPIO_Port GPIOF
#define HEAT_Pin GPIO_PIN_1
#define HEAT_GPIO_Port GPIOF
#define SIGN1_Pin GPIO_PIN_2
#define SIGN1_GPIO_Port GPIOA
#define WIND1_Pin GPIO_PIN_4
#define WIND1_GPIO_Port GPIOA
#define WIND2_Pin GPIO_PIN_5
#define WIND2_GPIO_Port GPIOA
#define MOTOR1_P_Pin GPIO_PIN_6
#define MOTOR1_P_GPIO_Port GPIOA
#define MOTOR1_M_Pin GPIO_PIN_7
#define MOTOR1_M_GPIO_Port GPIOA
#define MOTOR3_P_Pin GPIO_PIN_0
#define MOTOR3_P_GPIO_Port GPIOB
#define MOTOR3_M_Pin GPIO_PIN_1
#define MOTOR3_M_GPIO_Port GPIOB
#define MOTOR1_A_Pin GPIO_PIN_8
#define MOTOR1_A_GPIO_Port GPIOA
#define MOTOR1_B_Pin GPIO_PIN_9
#define MOTOR1_B_GPIO_Port GPIOA
#define EXIT1_Pin GPIO_PIN_10
#define EXIT1_GPIO_Port GPIOA
#define EXIT1_EXTI_IRQn EXTI4_15_IRQn
#define EXIT2_Pin GPIO_PIN_11
#define EXIT2_GPIO_Port GPIOA
#define EXIT2_EXTI_IRQn EXTI4_15_IRQn
#define EXIT3_Pin GPIO_PIN_12
#define EXIT3_GPIO_Port GPIOA
#define EXIT3_EXTI_IRQn EXTI4_15_IRQn
#define TODO2_Pin GPIO_PIN_15
#define TODO2_GPIO_Port GPIOA
#define TODO1_Pin GPIO_PIN_3
#define TODO1_GPIO_Port GPIOB
#define MOTOR2_P_Pin GPIO_PIN_4
#define MOTOR2_P_GPIO_Port GPIOB
#define MOTOR2_M_Pin GPIO_PIN_5
#define MOTOR2_M_GPIO_Port GPIOB
#define SIGN2_Pin GPIO_PIN_7
#define SIGN2_GPIO_Port GPIOB
/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
